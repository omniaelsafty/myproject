console.log('Hello World!');

document.write ("<div>this is written in js file</div>");